import random
from datetime import datetime
from datetime import timedelta
import statistics as stat

def get_num():
    '''
    1. description :
        get 10 sets of lotto number

    2. parameter 
        x
    3. returns
        result_num_list : list, 10 lengths and 2 dimension list array
    '''
    result_num_list = []
    while len(result_num_list) <10 :
        ran_list = random.sample(range(1,46),6)
        if stat.mean(ran_list) >= 20 and stat.mean(ran_list) < 25 :
            if stat.stdev(ran_list) >= 12 or stat.stdev(ran_list) < 16 :
                result_num_list.append(ran_list)

    return result_num_list


def get_date():
    '''
    1. description :
        get today and this saturday(lotto day)
    2. parameter 
        x
    3. returns
        today_str : str, yyyy-mm-dd
        saturday : str, yyyy-mm-dd
    '''
    now_ = datetime.now()
    today_str = f'{now_.year}-{now_.month}-{now_.day}'.format(now_.year)
    d = datetime.today()    
    sat_offset = 5 - d.weekday()

    saturday = d + timedelta(days=sat_offset)    
    saturday = str(saturday)[:10]
    print("Next Saturday :", saturday)

    return today_str, saturday